export const options = [
    { value: 'AL', label: 'Alabama' },
    { value: 'WY', label: 'Wyoming' },
    { value: 'WY', label: 'Coming' },
    { value: 'WY', label: 'Hanry Die' },
    { value: 'WY', label: 'John Doe' },
];

export const options2 = [
    { label: 'Developer', isDisabled: true },
    { value: 'AL', label: 'Alabama' },
    { value: 'WY', label: 'Wyoming' },
    { label: 'Designer', isDisabled: true },
    { value: 'WY', label: 'Coming' },
    { value: 'WY', label: 'Hanry Die' },
    { value: 'WY', label: 'John Doe' },
];

export const options3 = [
    { value: 'AL', label: 'First' },
    { value: 'WY', label: 'Second', isDisabled: true },
    { value: 'WY', label: 'Third' },
];

export const options4 = [
    { label: 'Developer', isDisabled: true },
    { value: 'AL', label: 'Alabama' },
    { value: 'WY', label: 'Wyoming' },
    { value: 'WY', label: 'Coming' },
    { value: 'WY', label: 'Hanry Die' },
    { value: 'WY', label: 'John Doe' },
];